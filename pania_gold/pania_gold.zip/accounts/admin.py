from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User,HomeImage,CompanySeller




class UserAdmin(BaseUserAdmin):
    list_display = ('mellicod', 'phone', 'f_name', 'l_name')  # نمایش فیلدها در لیست کاربران
    list_filter = ('is_active',)  # فیلتر کردن بر اساس فعال بودن
    fieldsets = (
        ('User Info', {'fields': ('mellicod', 'password')}),
        ('Personal Info', {'fields': ('f_name', 'l_name', 'phone')}),
        ('Permissions', {'fields': ('is_active', 'is_admin', 'is_superuser', 'permission')}),
    )
    # فیلدهایی که در صفحه افزودن کاربر جدید نمایش داده می‌شوند
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('mellicod', 'f_name', 'l_name', 'phone', 'password1', 'password2'),}),)
    search_fields = ('mellicod',)  # امکان جستجو بر اساس کد ملی
    ordering = ('mellicod',)  # مرتب‌سازی بر اساس کد ملی
    filter_horizontal = ('permission',)  # نمایش مجوزها به صورت افقی در پنل مدیریت



# ======================= مدیریت تصاویر صفحه اصلی ==========================
@admin.register(HomeImage)
class HomeImageAdmin(admin.ModelAdmin):
    list_display = ('id','description', 'image')

# # ======================= مدیریت فروشندگان ==========================
@admin.register(CompanySeller)
class SellerAdmin(admin.ModelAdmin):
    list_display = ('name', 'mellicode')
    search_fields = ('name',)





admin.site.register(User, UserAdmin)



