from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth import logout
from .models import HomeImage
from django.db.models import Q
from .forms import IndividualCustomerForm, CompanyCustomerForm, SupplierForm
from paniavault.models import Customer,Supplier




@login_required
def home_view(request):
    try:
        home_image = HomeImage.objects.get(description='home')
    except HomeImage.DoesNotExist:
        home_image = None
    context = {
        'home_image': home_image,
        'buyraw_invoice_register': reverse('paniavault:buyraw_invoice_register'),
        'create_recipt_melt_invoice': reverse('paniavault:create_recipt_melt_invoice'),
        'create_recipt_craft_invoice': reverse('paniavault:create_recipt_craft_invoice'),
        'vitrin_list': reverse('vitrin:vitrin_list'),

        'images': {
            'buyraw_invoice_register': 'media/home_images/rawgold.png',
            'create_recipt_melt_invoice': 'media/home_images/meltgold.png',
            'create_recipt_craft_invoice': 'media/home_images/craftgold.png',
            'vitrin_list': 'media/home_images/vitrin.png',

        },
    }
    return render(request, 'accounts/home.html', context)


# ---------------------------------------

def user_logout(request):
    logout(request)
    return redirect('accounts:login')  # بعد از لاگ‌اوت به صفحه لاگین هدایت می‌شود


def login_view(request):
    try:
        login_image = HomeImage.objects.get(description='login')
    except HomeImage.DoesNotExist:
        login_image = None
    if request.method == 'POST':
        user_id = request.POST['user_id']
        pass_code = request.POST['pass_code']
        user = authenticate(request, username=user_id, password=pass_code)
        if user is not None:
            login(request, user)
            return redirect('accounts:home')  # هدایت به صفحه demand بعد از ورود موفق
        else:
            messages.error(request, 'رمز عبور یا نام کاربری صحیح نیست')
    context = {
        'login_image': login_image,
    }
    return render(request, 'accounts/login.html',context)

# ------------------------------------
