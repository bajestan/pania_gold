from django import forms
from .models import MeltPiece,CraftPiece





# ----------------------------------
class MeltPieceForm(forms.ModelForm):
    class Meta:
        model = MeltPiece
        fields = ['weight', 'karat', 'ang_number', 'lab_name', 'additional_info','code']
        widgets = {
            'weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن قطعه',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;','required': 'required',
            }),
            'karat': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'عیار قطعه',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;','required': 'required',
            }),
            'ang_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'شماره انگ',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;','required': 'required',
            }),
            'lab_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'نام آزمایشگاه',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;','required': 'required',
            }),
            'additional_info': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'شرح',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',

            }),
            'code': forms.TextInput(attrs={
                'placeholder': 'کد کالا',
                'style': "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
        }
        labels = {
            'weight': '',
            'karat': '',
            'ang_number': '',
            'lab_name': '',
            'additional_info': '',
            'code': '',
        }

# -----------------------------------------
class CraftPieceForm(forms.ModelForm):
    class Meta:
        model = CraftPiece
        fields = ['gold_type','name','net_weight','weight_with_accessory', 'buy_ojrat', 'sale_ojrat', 'notes','code']
        widgets = {
            'gold_type': forms.Select(attrs={
                'class': 'form-control select2',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px',
                'required': 'required',
            }),
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'نام کالا',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'net_weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن قطعه',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'weight_with_accessory': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن با متعلقات',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
            }),
            'buy_ojrat': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'اجرت خرید',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
            }),
            'sale_ojrat': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'اجرت فروش',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
            }),
            'code': forms.TextInput(attrs={
                'placeholder': 'کد کالا',
                'style': "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
            'notes': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'شرح',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',

            }),
        }
        labels = {
            'gold_type': '',
            'name': '',
            'net_weight': '',
            'weight_with_accessory': '',
            'buy_ojrat': '',
            'sale_ojrat': '',
            'code': '',
            'notes': '',
        }