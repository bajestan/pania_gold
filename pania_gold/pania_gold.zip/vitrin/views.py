
from .models import CraftPiece,MeltPiece
from django.db.models import Q, Sum
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required





# ================ VITRIN ==============================
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import render


@login_required
def vitrin_list(request):
    if request.GET:
        request.session['vitrin_filters'] = {
            'name': request.GET.get('name', ''),
            'code': request.GET.get('code', ''),
        }
    filters = request.session.get('vitrin_filters', {})
    name = filters.get('name', '')
    code = filters.get('code', '')
    craftpieces = CraftPiece.objects.filter(is_sold=False).select_related('sale_invoice__customer', 'supplier')
    oldpieces = MeltPiece.objects.filter(is_sold=False).select_related('sale_invoice__customer', 'supplier')
    if name:
        if hasattr(CraftPiece, 'name'):  # بررسی وجود فیلد name در CraftPiece
            craftpieces = craftpieces.filter(
                Q(name__icontains=name) |
                Q(code__icontains=name)
            )
        else:
            craftpieces = craftpieces.filter(
                Q(code__icontains=name)
            )
        if hasattr(MeltPiece, 'name'):  # بررسی وجود فیلد name در MeltPiece
            oldpieces = oldpieces.filter(
                Q(name__icontains=name) |
                Q(code__icontains=name)
            )
        else:
            oldpieces = oldpieces.filter(
                Q(code__icontains=name)
            )
    if code:
        craftpieces = craftpieces.filter(code__icontains=code)
        oldpieces = oldpieces.filter(code__icontains=code)
    combined_golds = sorted(
        list(craftpieces) + list(oldpieces),
        key=lambda x: x.created_at,
        reverse=True
    )
    context = {
        'vitrins': combined_golds,
        'name': name,
        'code': code,
        'filters': filters,
    }
    return render(request, 'vitrin/vitrin_list.html', context)


# --------------------------------
@login_required
def cart_detail(request, golditem_id):
    try:
        vitrin = MeltPiece.objects.get(id=golditem_id)
    except MeltPiece.DoesNotExist:
        try:
            vitrin = CraftPiece.objects.get(id=golditem_id)
        except CraftPiece.DoesNotExist:
            vitrin = None

    if not vitrin:
        return render(request, 'vitrin/cart_detail_not_found.html')
    return render(request, 'vitrin/cart_detail.html', {'vitrin': vitrin})
