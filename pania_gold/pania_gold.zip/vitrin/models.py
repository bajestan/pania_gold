from django.db import models
from django_jalali.db import models as jmodels
from decimal import Decimal
from django.utils.timezone import now


class CompanyVitrin(models.Model):
    VITRIN_TYPE = [
        ('vitrin', 'بجستان'),
        ('safebox', 'تهران'),

    ]
    vitrin_type = models.CharField(max_length=20,null=True, blank=True, choices=VITRIN_TYPE, verbose_name='نوع ویترین')
    vitrin_balance=models.DecimalField(max_digits=20,decimal_places=3,default=Decimal('0.00'), verbose_name='موجودی ویترین')
    vitrin_assets =models.DecimalField(max_digits=20,decimal_places=3,default=Decimal('0.00'),null=True, blank=True, verbose_name='دارایی ویترین')
    notes = models.TextField(blank=True, null=True, verbose_name='شرح')
    created_at = models.DateTimeField(default=now, verbose_name='تاریخ ایجاد')
    updated_at = models.DateTimeField(default=now, verbose_name='تاریخ به‌روزرسانی')
    def __str__(self):
        return f"فاکتور فروش  {self.vitrin_balance}"


# =========================================  فاکتور فروش        =======================
class SaleInvoice(models.Model):
    customer = models.ForeignKey('paniavault.Customer', on_delete=models.CASCADE, verbose_name='مشتری')
    companyseller = models.ForeignKey('accounts.CompanySeller', on_delete=models.CASCADE, verbose_name='کارشناس فروش')
    sale_date = jmodels.jDateField(verbose_name='تاریخ فاکتور', null=True, blank=True)
    sale_dailyprice = models.PositiveIntegerField(null=True, blank=True, verbose_name='نرخ روز فروش')
    total_amount = models.BigIntegerField(null=True, blank=True, verbose_name='مجموع مبلغ')
    discount = models.IntegerField(null=True, blank=True, verbose_name='تخفیف')
    notes = models.TextField(blank=True, null=True, verbose_name='شرح')

    def __str__(self):
        return f"فاکتور فروش  {self.customer} - {self.sale_date}"

# ========================= آبشده =========================

class MeltPiece(models.Model):
    sale_invoice = models.ForeignKey(SaleInvoice, on_delete=models.SET_NULL, null=True, blank=True,related_name='melt_golds', verbose_name='فاکتور فروش آبشده')
    invoice = models.ForeignKey('paniavault.ReciptMeltInvoice',on_delete=models.CASCADE,verbose_name='فاکتور بنکدار',related_name='melt_pieces')
    vitrin = models.ForeignKey(CompanyVitrin, on_delete=models.SET_NULL,null=True, blank=True, verbose_name='ویترین', related_name='melt_vitrin')
    supplier = models.ForeignKey('paniavault.Supplier', on_delete=models.CASCADE, null=True, blank=True,
                                 verbose_name='تأمین‌کننده', related_name='meltpiece_supllier')
    code = models.CharField(max_length=100, unique=True, null=True, blank=True, verbose_name='کد کار')
    net_weight = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'),verbose_name='وزن خالص قطعه')
    weight = models.DecimalField(max_digits=10,decimal_places=2,verbose_name='وزن قطعه')
    karat = models.DecimalField(max_digits=3,decimal_places=0,verbose_name='عیارقطعه' )
    ang_number = models.CharField(max_length=50,blank=True,null=True,verbose_name='شماره انگ')
    lab_name = models.CharField( max_length=100,blank=True,null=True,verbose_name='نام آزمایشگاه')
    is_sold = models.BooleanField(default=False, verbose_name='وضعیت فروش')
    additional_info = models.TextField(verbose_name='اطلاعات اضافی',blank=True,null=True )
    created_at = models.DateTimeField(default=now, verbose_name='تاریخ ایجاد')
    def __str__(self):
        return f"قطعه {self.ang_number} ({self.weight} گرم - {self.karat} عیار)"


# ==============CRAFTED GOLD  زینتی ================================

class CraftPiece(models.Model):
    # نام اول دسته بندی برای تولید کد حروف مشابه نباشد
    CATEGORY = [
        ('ring', 'انگشتر'),
        ('set', 'ست و نیم ست'),
        ('minimal', 'مینیمال'),
        ('earring', 'گوشواره'),
        ('bracelet', 'دستبند'),
        ('child', 'کودک'),
    ]
    invoice = models.ForeignKey('paniavault.ReciptCraftInvoice', on_delete=models.CASCADE, verbose_name='فاکتور بنکدار',related_name='caft_pieces')
    vitrin = models.ForeignKey(CompanyVitrin, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='ویترین', related_name='caft_vitrin')
    sale_invoice = models.ForeignKey(SaleInvoice, on_delete=models.SET_NULL, null=True, blank=True, related_name='crafted_golds', verbose_name='فاکتور فروش')
    gold_type = models.CharField(max_length=50, choices=CATEGORY,null=True, blank=True, verbose_name='دسته بندی')
    code = models.CharField(max_length=100,unique=True, null=True, blank=True, verbose_name='کد کار')
    name = models.CharField(max_length=100, null=True, blank=True, verbose_name='نام کالا')
    net_weight = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,verbose_name='وزن خالص')
    weight_with_accessory = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,verbose_name='وزن با متعلقات')

    supplier = models.ForeignKey('paniavault.Supplier', on_delete=models.CASCADE, null=True, blank=True, verbose_name='تأمین‌کننده',related_name='craftedpiece_supllier')
    buy_price = models.IntegerField(null=True, blank=True, verbose_name='قیمت خرید')
    buy_date = jmodels.jDateField(verbose_name='تاریخ خرید', null=True, blank=True)
    buy_ojrat = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True, verbose_name='اجرت خرید')
    buy_dailyprice = models.PositiveIntegerField(null=True, blank=True, verbose_name='نرخ روز طلا')

    sale_price = models.IntegerField(null=True, blank=True, verbose_name='قیمت فروش')
    sale_date = jmodels.jDateField(verbose_name='تاریخ فروش', null=True, blank=True)
    sale_ojrat = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True, verbose_name='اجرت فروش')
    sale_tax = models.IntegerField(null=True, blank=True,verbose_name='مالیات فروش')
    notes = models.TextField(blank=True, null=True, verbose_name='شرح')
    is_sold= models.BooleanField(default=False, verbose_name='وضعیت فروش')
    created_at = models.DateTimeField(default=now, verbose_name='تاریخ ایجاد')
    image = models.ImageField(upload_to='craftedgold_image/', blank=True, null=True, verbose_name='تصویر بند انگشتی')

    def __str__(self):
        return f" {self.net_weight}"

# ======================== OLD GOLD طلای مستعمل  ==============
class OldPiece(models.Model):
    sale_invoice = models.ForeignKey(SaleInvoice, on_delete=models.SET_NULL, null=True, blank=True, related_name='old_golds', verbose_name='فاکتور فروش')
    code = models.CharField(max_length=100,unique=True, null=True, blank=True, verbose_name='کد کار')
    name = models.CharField(max_length=100, null=True, blank=True, verbose_name='نام کالا')
    net_weight = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,verbose_name='وزن خالص')
    weight_with_accessory = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True,verbose_name='وزن با متعلقات')

    supplier = models.ForeignKey('paniavault.Supplier', on_delete=models.CASCADE, null=True, blank=True, verbose_name='تأمین‌کننده',related_name='old_supllier')
    buy_price = models.IntegerField(null=True, blank=True, verbose_name='قیمت خرید')
    buy_date = jmodels.jDateField(verbose_name='تاریخ خرید', null=True, blank=True)
    buy_dailyprice = models.PositiveIntegerField(null=True, blank=True, verbose_name='نرخ روز طلا')

    sale_price = models.IntegerField(null=True, blank=True, verbose_name='قیمت فروش')
    sale_date = jmodels.jDateField(verbose_name='تاریخ فروش', null=True, blank=True)
    sale_ojrat = models.DecimalField(max_digits=15, decimal_places=2, null=True, blank=True, verbose_name='اجرت فروش')
    sale_tax = models.IntegerField(null=True, blank=True,verbose_name='مالیات فروش')
    notes = models.TextField(blank=True, null=True, verbose_name='شرح')
    is_sold= models.BooleanField(default=False, verbose_name='وضعیت فروش')
    created_at = models.DateTimeField(default=now, verbose_name='تاریخ ایجاد')
    image = models.ImageField(upload_to='oldgold_image/', blank=True, null=True, verbose_name='تصویر بند انگشتی')

    def __str__(self):
        return f" {self.net_weight}"