from django.urls import path
from . import views



app_name = 'vitrin'
urlpatterns = [
        path('vitrin_list/', views.vitrin_list, name='vitrin_list'),
        path('cart_detail/<int:golditem_id>/', views.cart_detail, name='cart_detail'),

]