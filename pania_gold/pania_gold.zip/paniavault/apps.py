from django.apps import AppConfig


class PaniavaultConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "paniavault"

    def ready(self):
        import paniavault.signals