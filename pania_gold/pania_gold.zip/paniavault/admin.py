from django.contrib import admin, messages
from .models import BuyRawInvoice,ReciptMeltInvoice,ReciptCraftInvoice
from .models import Customer,Supplier
from .forms import BuyRawInvoiceForm
from django.core.exceptions import ValidationError






@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('last_name','first_name',  'customer_type', 'phone_number', 'city', 'total_gold_balance', 'total_gold_reserve')
    search_fields = ('first_name', 'last_name', 'mellicode', 'phone_number')
    list_filter = ('customer_type', 'city')
    ordering = ('last_name',)
# ----------------------------------



@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('last_name','first_name', 'phone_number',  'mellicode', 'phone', 'city', 'code_posti', 'address')
    list_filter = ('city',)
    search_fields = ('first_name', 'last_name', 'mellicode', 'phone_number')  # قابلیت جستجو
    ordering = ('last_name',)

    def full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    full_name.short_description = "نام کامل"



# ------------------------------------------

class BuyRawInvoiceAdmin(admin.ModelAdmin):
    list_display = (
        'gold_type', 'supplier',  'invoice_date',
        'net_weight', 'invoice_price', 'discount', 'companyseller','notes'
    )
    search_fields = ('supplier__name', 'vault__name', 'companyseller__name', 'invoice_date')
    list_filter = ('gold_type', 'supplier', 'vault', 'companyseller', 'invoice_date')
    fieldsets = (
        (None, {
            'fields': ('gold_type', 'supplier',  'companyseller', 'invoice_date')
        }),
        ('مالی', {
            'fields': ('net_weight', 'invoice_dailyprice', 'invoice_price', 'discount')
        }),
        ('توضیحات', {
            'fields': ('notes',)
        })
    )
    list_editable = ('invoice_price', 'discount')
    list_per_page = 20

    form = BuyRawInvoiceForm  # تنظیم فرم در پنل ادمین


# ----------------------------------
class ReciptMeltInvoiceAdmin(admin.ModelAdmin):
    list_display = (
        'supplier', 'vault', 'invoice_date', 'net_weight', 'created_at'
    )
    search_fields = ('supplier__name', 'vault__name', 'invoice_date')
    list_filter = ('supplier', 'vault', 'invoice_date')
    fieldsets = (
        (None, {
            'fields': ('supplier', 'vault', 'invoice_date')
        }),
        ('مالی', {
            'fields': ('net_weight',)
        }),
        ('تاریخ و زمان', {
            'fields': ('created_at',)
        })
    )
    list_editable = ('net_weight',)
    list_per_page = 20

# -------------------------------------------
class ReciptCraftInvoiceAdmin(admin.ModelAdmin):
    list_display = (
        'supplier', 'vault', 'invoice_date', 'net_weight', 'created_at'
    )
    search_fields = ('supplier__name', 'vault__name', 'invoice_date')
    list_filter = ('supplier', 'vault', 'invoice_date')
    fieldsets = (
        (None, {
            'fields': ('supplier', 'vault', 'invoice_date')
        }),
        ('مالی', {
            'fields': ('net_weight',)
        }),
        ('تاریخ و زمان', {
            'fields': ('created_at',)
        })
    )
    list_editable = ('net_weight',)
    list_per_page = 20








admin.site.register(BuyRawInvoice, BuyRawInvoiceAdmin)
admin.site.register(ReciptMeltInvoice, ReciptMeltInvoiceAdmin)
admin.site.register(ReciptCraftInvoice, ReciptCraftInvoiceAdmin)