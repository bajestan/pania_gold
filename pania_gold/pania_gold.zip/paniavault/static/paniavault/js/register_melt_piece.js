

// جابجایی بین فیلدها با زدن کلید Enter
document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        event.preventDefault(); // جلوگیری از ارسال فرم به صورت پیش‌فرض
        const formElements = Array.from(document.querySelectorAll("form input, form select, form textarea, form button"));
        const activeElement = document.activeElement;
        const currentIndex = formElements.indexOf(activeElement);
        const nextIndex = (currentIndex + 1) % formElements.length;

        if (nextIndex !== 0) {
            formElements[nextIndex].focus();
        }
    }
});


// تابع برای تولید کد کالا
function generateCode() {
    const karatField = document.getElementById('id_karat');
    const weightField = document.getElementById('id_weight');
    const codeField = document.getElementById('id_code');

    const karat = karatField ? parseFloat(karatField.value) : null;
    const weight = weightField ? parseFloat(weightField.value) : null;

    if (karat && weight) {
        // بخش صحیح و اعشاری وزن
        const intPart = Math.floor(weight);
        const decPart = Math.round((weight - intPart) * 100).toString().padStart(2, '0');
        const formattedWeight = `${intPart.toString().padStart(2, '0')}${decPart}`;

        // کاراکترهای عیار
        const formattedKarat = Math.floor(karat).toString().padStart(3, '0');

        // تولید بخش یکتای تایم‌استمپ
        const timestamp = new Date().getTime().toString().slice(-1); // 1 کاراکتر آخر

        // تولید کد نهایی با فرمت جدید
        const generatedCode = `ME${timestamp}-${formattedKarat}-${formattedWeight}`;

        // تنظیم مقدار فیلد کد
        if (codeField) {
            codeField.value = generatedCode;
        }
    }
}

// اجرای تابع با تغییر فیلدها
document.getElementById('id_karat').addEventListener('input', generateCode);
document.getElementById('id_weight').addEventListener('input', generateCode);
