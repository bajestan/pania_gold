from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Sum
from django.shortcuts import render, redirect, get_object_or_404,reverse
from .forms import BuyRawInvoiceForm,ReciptMeltInvoiceForm,ReciptCraftInvoiceForm
from .models import BuyRawInvoice,CompanyVault,ReciptMeltInvoice,ReciptCraftInvoice
from vitrin.models import MeltPiece,CraftPiece
from vitrin.forms import MeltPieceForm,CraftPieceForm
import jdatetime
import time







# ثبت خرید طلای خام----------

@login_required
def buyraw_invoice_register(request):
    vault, created = CompanyVault.objects.get_or_create(
        defaults={'company_balance': 0, 'company_assets': 0}
    )
    if request.method == 'POST':
        form = BuyRawInvoiceForm(request.POST)
        jalali_date = request.POST.get('invoice_date')
        if jalali_date:
            try:
                formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
                form.data = form.data.copy()
                form.data['invoice_date'] = formatted_date
            except ValueError:
                form.add_error('invoice_date', 'تاریخ وارد شده نامعتبر است.')
        if form.is_valid():
            raw_invoice = form.save(commit=False)  # ذخیره موقت
            raw_invoice.vault = vault
            raw_invoice.save()
            return redirect('paniavault:buyraw_invoice_list')  # تغییر مسیر به لیست فاکتورها
    else:
        form = BuyRawInvoiceForm()
    return render(request, 'paniavault/buyraw_invoice_register.html', {'form': form})



# --------------------------------------


@login_required
def buyraw_invoice_list(request):
    if request.GET:
        request.session['supply_filters'] = {
            'supply': request.GET.get('supply', ''),
        }
    filters = request.session.get('supply_filters', {})
    supply_name = filters.get('supply', '')
    invoices = BuyRawInvoice.objects.all()
    if supply_name:
        invoices = invoices.filter(
            Q(supplier__first_name__icontains=supply_name) |
            Q(supplier__last_name__icontains=supply_name)
        )
    invoices = invoices.order_by('-created_at')[:10]
    context = {
        'invoices': invoices,
        'supply_name': supply_name,
        'filters': filters,
    }
    return render(request, 'paniavault/buyraw_invoice_list.html', context)

# --------------------------------------------

@login_required
def company_vault_list(request):
    vaults = CompanyVault.objects.all()
    for vault in vaults:
        print(f"Vault ID: {vault.id}")
        print(f"  - Company Balance: {vault.company_balance}")
        print(f"  - Company Assets: {vault.company_assets}")
        print(f"  - Notes: {vault.notes}")
        print("===================================")

    return render(request, 'paniavault/company_vault_list.html', {'vaults': vaults})

# -------------------------------------
@login_required
def create_recipt_melt_invoice(request):
    if request.method == 'POST':
        form = ReciptMeltInvoiceForm(request.POST)
        jalali_date = request.POST.get('invoice_date')
        if jalali_date:
            try:
                formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
                form.data = form.data.copy()
                form.data['invoice_date'] = formatted_date
            except ValueError:
                form.add_error('invoice_date', 'تاریخ وارد شده نامعتبر است.')
        # بررسی صحت فرم و فرم‌ست
        if form.is_valid() :
            invoice = form.save(commit=False)
            if not invoice.vault_id:
                default_vault = CompanyVault.objects.first()
                if not default_vault:
                    form.add_error(None, 'هیچ ولتی برای شرکت تعریف نشده است. لطفاً یک ولت اضافه کنید.')
                    return render(request, 'paniavault/create_recipt_melt_invoice.html', {
                        'form': form,
                    })
                invoice.vault = default_vault
            invoice.save()  # ذخیره فاکتور
            return redirect('paniavault:recipt_melt_invoice_list')
    else:
        form = ReciptMeltInvoiceForm()
    return render(request, 'paniavault/create_recipt_melt_invoice.html', {
        'form': form,
    })

# ------------ثبت خرید قطعه ابشده در فاکتور اصلی ------------------

@login_required
def register_melt_piece(request, invoice_id):
    invoice = get_object_or_404(ReciptMeltInvoice, id=invoice_id)
    pieces = MeltPiece.objects.filter(invoice=invoice)
    if request.method == 'POST':
        form = MeltPieceForm(request.POST)
        if form.is_valid():
            karat = form.cleaned_data['karat']
            weight = form.cleaned_data['weight']
            code = form.cleaned_data.get('code')
            if not code:  # اگر کد وجود ندارد
                if weight is not None:
                    int_part = int(weight)
                    dec_part = int((weight - int_part) * 100)
                    formatted_weight = f"{int_part:02d}{dec_part:02d}"
                else:
                    formatted_weight = "0000"
                timestamp = str(int(time.time() % 10))  # یک کاراکتر از تایم‌استمپ
                formatted_karat = f"{int(karat):03d}"[:3]  # سه کاراکتر از عیار
                # تولید کد با فرمت جدید
                generated_code = f"ME{timestamp}-{formatted_karat}-{formatted_weight}"
                form.instance.code = generated_code
            else:
                form.instance.code = code

            piece = form.save(commit=False)
            piece.invoice = invoice
            piece.save()
            messages.success(request, "قطعه با موفقیت ثبت شد.")
            return redirect(reverse('paniavault:register_melt_piece', args=[invoice_id]))
    else:
        form = MeltPieceForm()

    return render(request, 'paniavault/register_melt_piece.html', {
        'form': form,
        'invoice': invoice,
        'pieces': pieces,
    })


# ------------------لیست فاکتورهای خرید ابشده---------------------------

@login_required
def recipt_melt_invoice_list(request):
    if request.GET:
        request.session['supply_filters'] = {
            'supply': request.GET.get('supply', ''),
        }
    filters = request.session.get('supply_filters', {})
    supply_name = filters.get('supply', '')
    invoices = ReciptMeltInvoice.objects.prefetch_related('melt_pieces').all()

    if supply_name:
        invoices = invoices.filter(
            Q(supplier__first_name__icontains=supply_name) |
            Q(supplier__last_name__icontains=supply_name)
        )
    invoices = invoices.order_by('-created_at')[:10]
    context = {
        'invoices': invoices,
        'supply_name': supply_name,
        'filters': filters,
    }
    return render(request, 'paniavault/recipt_melt_invoice_list.html', context)

# ========================= CRAFT =========================

# --------------------------فاکتور دریاقت زینتی از بنکدار---------------

@login_required
def create_recipt_craft_invoice(request):
    if request.method == 'POST':
        form = ReciptCraftInvoiceForm(request.POST)
        jalali_date = request.POST.get('invoice_date')
        if jalali_date:
            try:
                formatted_date = jdatetime.datetime.strptime(jalali_date, '%Y/%m/%d').strftime('%Y-%m-%d')
                form.data = form.data.copy()
                form.data['invoice_date'] = formatted_date
            except ValueError:
                form.add_error('invoice_date', 'تاریخ وارد شده نامعتبر است.')
        # بررسی صحت فرم و فرم‌ست
        if form.is_valid() :
            invoice = form.save(commit=False)
            if not invoice.vault_id:
                default_vault = CompanyVault.objects.first()
                if not default_vault:
                    form.add_error(None, 'هیچ ولتی برای شرکت تعریف نشده است. لطفاً یک ولت اضافه کنید.')
                    return render(request, 'paniavault/create_recipt_craft_invoice.html', {
                        'form': form,
                    })
                invoice.vault = default_vault
            invoice.save()  # ذخیره فاکتور
            return redirect('paniavault:recipt_craft_invoice_list')
    else:
        form = ReciptCraftInvoiceForm()
    return render(request, 'paniavault/create_recipt_craft_invoice.html', {
        'form': form,
    })
# ----------------------------لیست فاکتورهای زینتی---------------
@login_required
def recipt_craft_invoice_list(request):
    if request.GET:
        request.session['supply_filters'] = {
            'supply': request.GET.get('supply', ''),
        }
    filters = request.session.get('supply_filters', {})
    supply_name = filters.get('supply', '')
    invoices = ReciptCraftInvoice.objects.all()

    if supply_name:
        invoices = invoices.filter(
            Q(supplier__first_name__icontains=supply_name) |
            Q(supplier__last_name__icontains=supply_name)
        )
    invoices = invoices.order_by('-created_at')[:10]
    context = {
        'invoices': invoices,
        'supply_name': supply_name,
        'filters': filters,
    }
    return render(request, 'paniavault/recipt_craft_invoice_list.html', context)

# ------------ثبت خرید قطعه زینتی در فاکتور اصلی ------------------

@login_required
def register_craft_piece(request, invoice_id):
    invoice = get_object_or_404(ReciptCraftInvoice, id=invoice_id)
    pieces = CraftPiece.objects.filter(invoice=invoice)
    if request.method == 'POST':
        form = CraftPieceForm(request.POST)
        if form.is_valid():
            gold_type = form.cleaned_data['gold_type']
            sale_ojrat = form.cleaned_data['sale_ojrat']
            net_weight = form.cleaned_data['net_weight']
            code = form.cleaned_data.get('code')
            if not code:  # اگر کد وجود ندارد
                if net_weight is not None:
                    int_part = int(net_weight)
                    dec_part = int((net_weight - int_part) * 100)
                    formatted_net_weight = f"{int_part:02d}{dec_part:02d}"
                else:
                    formatted_net_weight = "0000"
                timestamp = str(int(time.time() % 10))  # یک کاراکتر از تایم‌استمپ
                formatted_sale_ojrat = f"{int(sale_ojrat):02d}"[:2]  # سه کاراکتر از عیار
                first_letter = gold_type[:2].upper() if gold_type else ''
                generated_code = f"{first_letter}-{timestamp}-{formatted_sale_ojrat}-{formatted_net_weight}"
                form.instance.code = generated_code
            else:
                form.instance.code = code

            piece = form.save(commit=False)
            piece.invoice = invoice
            piece.save()
            messages.success(request, "قطعه با موفقیت ثبت شد.")
            return redirect(reverse('paniavault:register_craft_piece', args=[invoice_id]))
    else:
        form = CraftPieceForm()
    return render(request, 'paniavault/register_craft_piece.html', {
        'form': form,
        'invoice': invoice,
        'pieces': pieces,
    })
