from django import forms
from .models import BuyRawInvoice,ReciptMeltInvoice, ReciptCraftInvoice
from django.forms.models import inlineformset_factory






class BuyRawInvoiceForm(forms.ModelForm):
    class Meta:
        model = BuyRawInvoice
        fields = [
            'gold_type', 'supplier', 'companyseller',
            'invoice_date', 'net_weight', 'invoice_dailyprice',
            'invoice_price', 'discount', 'notes'
        ]
        widgets = {
            'gold_type': forms.Select(attrs={
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
            'supplier': forms.Select(
                attrs={'class': 'form-control select2',
                       'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;', 'required': 'required'}),
            'companyseller': forms.Select(attrs={
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
            'invoice_date': forms.TextInput(attrs={'data-jdp': 'true','class': 'form-control',"placeholder":"تاریخ فاکتور" ,
                       "style": "font-family: Vazirmatn, sans-serif;"
                        " font-size: 12px", 'required': 'required','autocomplete': 'off'}),
            'net_weight': forms.NumberInput(attrs={
                "placeholder": "وزن خالص",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",'required': 'required',
                'min': '0.01'
            }),
            'invoice_dailyprice': forms.NumberInput(attrs={
                "placeholder": "نرخ روز طلا",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",'required': 'required'
            }),
            'invoice_price': forms.NumberInput(attrs={
                "placeholder": "مبلغ فاکتور",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",'required': 'required'
            }),
            'discount': forms.NumberInput(attrs={
                "placeholder": "تخفیف",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
            }),
            'notes': forms.TextInput(attrs={
                "placeholder": "توضیحات",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
            }),
        }
        labels = {
            'gold_type': '',
            'supplier': '',
            'companyseller': '',
            'invoice_date': '',
            'net_weight': '',
            'invoice_dailyprice': '',
            'invoice_price': '',
            'discount': '',
            'notes': '',
        }
# --------------------------------------


class ReciptMeltInvoiceForm(forms.ModelForm):
    class Meta:
        model = ReciptMeltInvoice
        fields = ['melt_type','supplier',  'invoice_date','invoice_serial', 'net_weight']
        widgets = {
            'melt_type': forms.Select(attrs={
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
            'supplier': forms.Select(attrs={
                'class': 'form-control select2',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'invoice_date': forms.TextInput(attrs={
                'data-jdp': 'true',
                'class': 'form-control',
                'required': True,
                'placeholder': 'تاریخ فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px',
                'autocomplete': 'off',
            }),
            'invoice_serial': forms.TextInput(attrs={
                'placeholder': 'سریال فاکتور',
                'style': "font-family: Vazirmatn, sans-serif; font-size: 12px",

            }),
            'net_weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن خالص فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
                'min': '0.01',
            }),
        }
        labels = {
            'supplier': '',
            'invoice_date': '',
            'invoice_serial': '',
            'net_weight': '',
        }

# ----------------------------

class ReciptCraftInvoiceForm(forms.ModelForm):
    class Meta:
        model = ReciptCraftInvoice
        fields = ['pay_type','supplier', 'companyseller' ,'invoice_date','invoice_serial', 'net_weight','accessory_weight','qty','invoice_dailyprice','discount','notes']
        widgets = {
            'pay_type': forms.Select(attrs={
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
                'required': 'required'
            }),
            'supplier': forms.Select(attrs={
                'class': 'form-control select2',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'companyseller': forms.Select(attrs={
                'class': 'form-control select',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'invoice_date': forms.TextInput(attrs={
                'data-jdp': 'true',
                'class': 'form-control',
                'required': True,
                'placeholder': 'تاریخ فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px',
                'autocomplete': 'off',
            }),
            'invoice_serial': forms.TextInput(attrs={
                'placeholder': 'سریال فاکتور',
                'style': "font-family: Vazirmatn, sans-serif; font-size: 12px",

            }),
            'net_weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن خالص فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
                'min': '0.01',
            }),
            'accessory_weight': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'وزن با متعلقات فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
            }),
            'qty': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'تعداد اقلام فاکتور',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'invoice_dailyprice': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'نرخ روز طلا',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',
                'required': 'required',
            }),
            'discount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'تخفیف',
                'style': 'font-family: Vazirmatn, sans-serif; font-size: 12px;',

            }),
            'notes': forms.TextInput(attrs={
                "placeholder": "توضیحات",
                "style": "font-family: Vazirmatn, sans-serif; font-size: 12px",
            }),
        }
        labels = {
            'supplier': '',
            'companyseller':'',
            'invoice_date': '',
            'invoice_serial': '',
            'net_weight': '',
            'accessory_weight': '',
            'qty': '',
            'invoice_dailyprice':'',
            'discount': '',
            'notes':'',
        }

